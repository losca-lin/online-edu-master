package xyz.refrain.onlineedu.mapper;

import xyz.refrain.onlineedu.model.entity.AclRoleEntity;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  角色 Mapper 接口
 * </p>
 *
 * @author snwjas
 * @since 2021-05-02
 */
public interface AclRoleMapper extends BaseMapper<AclRoleEntity> {

}
