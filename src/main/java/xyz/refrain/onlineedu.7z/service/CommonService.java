package xyz.refrain.onlineedu.service;

/**
 * 提供一些公共方法
 *
 * @author Myles Yang
 */
public class CommonService {
}
